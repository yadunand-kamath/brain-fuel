package com.brainfuel.brainfood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrainFoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
